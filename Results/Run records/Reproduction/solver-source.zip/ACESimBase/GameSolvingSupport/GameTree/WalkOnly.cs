﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ACESimBase.GameSolvingSupport.GameTree
{
    public class WalkOnly : ITreeNodeProcessor<bool, bool> // bools are ignored
    {
        public bool ChanceNode_Backward(ChanceNode chanceNode, IEnumerable<bool> fromSuccessors)
        {
            return true;
        }

        public bool ChanceNode_Forward(ChanceNode chanceNode, IGameState predecessor, byte predecessorAction, bool fromPredecessor)
        {
            return true;
        }

        public bool FinalUtilities_TurnAround(FinalUtilitiesNode finalUtilities, IGameState predecessor, byte predecessorAction, bool fromPredecessor)
        {
            return true;
        }

        public bool InformationSet_Backward(InformationSetNode informationSet, IEnumerable<bool> fromSuccessors)
        {
            return true;
        }

        public bool InformationSet_Forward(InformationSetNode informationSet, IGameState predecessor, byte predecessorAction, bool fromPredecessor)
        {
            return true;
        }
    }
}
