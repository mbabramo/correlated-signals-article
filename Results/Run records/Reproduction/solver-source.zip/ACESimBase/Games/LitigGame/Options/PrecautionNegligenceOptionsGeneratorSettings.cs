﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ACESimBase.Games.LitigGame.Options
{
    public class PrecautionNegligenceOptionsGeneratorSettings
    {
        public bool UseSimplifiedPrecautionNegligenceGame = false;
        public byte ParameterForMultipleOptions_Simplified = 2;
        public byte ParameterForMultipleOptions = 10;

        public bool CollapseDecisionsInSimplifiedPrecautionNegligenceGame = true; 
        public bool PerfectAdjudication = false;
        public bool PerfectInformationToo = false;

        public byte NumPotentialBargainingRounds = 1; 
        public bool AllowQuitting = true;
        public bool PredeterminedAbandonAndDefaults = false; // should be false when doing more than one bargaining round OR when using CFR.

    }
}
